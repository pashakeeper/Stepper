$(document).ready(function () {
    $('#step_01 input[type="checkbox"]').on('change', function () {
        $('#step_01 input[type="checkbox"]').not(this).prop('checked', false);
    });
    $('#step_02 input[type="checkbox"]').on('change', function () {
        $('#step_02 input[type="checkbox"]').not(this).prop('checked', false);
    });
    $('#step_03 input[type="checkbox"]').on('change', function () {
        $('#step_03 input[type="checkbox"]').not(this).prop('checked', false);
    });
    $('#step_04 input[type="checkbox"]').on('change', function () {
        $('#step_04 input[type="checkbox"]').not(this).prop('checked', false);
    });
    $('form').on('change', function () {
        let sm = $('input:checked').val();
        console.log(sm);
    })
    $("form").steps({
        headerTag: "h3",
        bodyTag: "section",
        transitionEffect: "slideLeft",
        autoFocus: true
    });


    //Can change 7 to 2 for longer results.
    let r = (Math.random() + 1).toString(36).substring(7);
    console.log("random", r);

});